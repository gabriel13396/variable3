[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-24ddc0f5d75046c5622901739e7c5dd533143b0c8e959d652212380cedb1ea36.svg)](https://classroom.github.com/a/b5U3qeNA)
# Business Need:
A school wants to develop a simple application that calculates the average grade for a student based on their course grades and credits.

# User Story:
As a student, I want to enter my course grades and credits to calculate my GPA (Grade Point Average).
